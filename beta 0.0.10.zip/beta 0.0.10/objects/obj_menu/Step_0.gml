//Controles do menu principal
if (global.menu_estado == "principal")
{
    //Mudando de opção
    if (keyboard_check_pressed(vk_down))
    {
        atual++;
        margem = 0;
    }
    if (keyboard_check_pressed(vk_up)) 
    {
        atual--;
        margem = 0;
    }

    //Limitando a variavel atual
    atual = clamp(atual, 0, array_length(menu) -1);

    //Se apertar enter, executa a função do menu
    if (keyboard_check_pressed(vk_enter))
    {
        menu[atual].funcao();
    }
    
    //Fazendo o valor da margem aumentar
    margem = lerp(margem, 20, .2);
}
//Controles do menu de opções
else if (global.menu_estado == "opcoes")
{
    //Ajustando volume
    if (keyboard_check(vk_left))
    {
        global.volume_musica = max(0, global.volume_musica - 0.01);
        audio_sound_gain(snd_soundtrack_fase1, global.volume_musica, 0);
    }
    if (keyboard_check(vk_right))
    {
        global.volume_musica = min(1, global.volume_musica + 0.01);
        audio_sound_gain(snd_soundtrack_fase1, global.volume_musica, 0);
    }
    
    //Voltar ao menu principal
    if (keyboard_check_pressed(vk_escape))
    {
        global.menu_estado = "principal";
    }
}