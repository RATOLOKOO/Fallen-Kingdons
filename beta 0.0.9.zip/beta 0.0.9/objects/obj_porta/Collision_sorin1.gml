audio_stop_all();
persistent = true;
room_goto(rm_boss);