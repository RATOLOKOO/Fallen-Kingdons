// === MOVIMENTO BÁSICO ===
x += velocidade * direcao;

// Verifica colisão com o limite da room (inverte direção)
if (x <= 0 || x >= room_width - sprite_width) {
    direcao *= -1;
}

// Ajusta sprite para direção
image_xscale = sign(direcao);

// === GRAVIDADE ===
if (!place_meeting(x, y + 1, obj_grama)) {
    y += 4; // queda simples
} else {
    while (place_meeting(x, y, obj_grama)) {
        y -= 1;
    }
}

// === VIDA ===
if (vida <= 0) {
    instance_destroy();
}