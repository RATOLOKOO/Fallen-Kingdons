// Criar o jogador
var _player = instance_create_layer(64, room_height - 128, "Instances", sorin1);

// Garantir que as variáveis do jogador sejam inicializadas
with(_player) {
    // Variáveis de movimento
    vspd = 0;
    grv = 0.5;
    pulo = -10;
    spd = 4;
    
    // Sistema de vida
    vidas = 3;
    invencivel = false;
    alpha_padrao = 1;
    
    // Configurar a câmera
    cam_w = 640;
    cam_h = 360;
    camera = camera_create_view(0, 0, cam_w, cam_h, 0, -1, -1, -1, cam_w/2, cam_h/2);
    view_camera[0] = camera;
}

// Criar o boss
instance_create_layer(room_width - 192, room_height - 192, "Instances", obj_boss);

// Inicializar o controller da sala se necessário
if (!instance_exists(obj_controller)) {
    instance_create_layer(0, 0, "Instances", obj_controller);
}

// Destruir a porta após configurar tudo
instance_destroy();