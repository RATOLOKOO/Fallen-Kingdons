//Efeito de piscar durante a invencibilidade
if (invencivel)
{
    //Alterna entre visível e semi-transparente
    if (image_alpha == alpha_padrao)
        image_alpha = 0.5;
    else
        image_alpha = alpha_padrao;
    
    //Continua o efeito enquanto estiver invencível
    alarm[1] = tempo_piscar;
}