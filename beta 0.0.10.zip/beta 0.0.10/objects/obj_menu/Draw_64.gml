//Configurando fonte
draw_set_font(fnt_menu);
var _altura = string_height("I") * 2.5; // Aumentei o espaçamento vertical
draw_set_halign(fa_center); // Centraliza o texto horizontalmente

if (global.menu_estado == "principal")
{
    // Calculando posições centralizadas
    var _largura_tela = display_get_gui_width();
    var _altura_tela = display_get_gui_height();
    var _centro_x = _largura_tela / 2;
    var _inicio_y = _altura_tela / 2 - (_altura * array_length(menu) / 2);
    
    //Desenhando menu principal
    for (var i = 0; i < array_length(menu); i++)
    {
        var _cor = c_white;
        var _margem = 0;
        var _escala = 1.5; // Escala base do texto
        
        //checando se a opção atual está selecionada
        if (i == atual)
        {
            _cor = c_red;
            _margem = margem;
            _escala = 1.8; // Escala maior para a opção selecionada
        }
        
        draw_set_color(_cor);
        
        // Definindo a escala do texto
        draw_set_font(fnt_menu);
        draw_text_transformed(_centro_x + _margem, _inicio_y + _altura * i, menu[i].texto, _escala, _escala, 0);
        
        // Desenhando uma linha decorativa sob o texto
        if (i == atual)
        {
            var _texto_largura = string_width(menu[i].texto) * _escala;
            draw_line_width(_centro_x - _texto_largura/2 + _margem, 
                           _inicio_y + _altura * i + string_height(menu[i].texto) * _escala, 
                           _centro_x + _texto_largura/2 + _margem, 
                           _inicio_y + _altura * i + string_height(menu[i].texto) * _escala,
                           3);
        }
    }
}
else if (global.menu_estado == "opcoes")
{
    var _largura_tela = display_get_gui_width();
    var _altura_tela = display_get_gui_height();
    var _centro_x = _largura_tela / 2;
    var _inicio_y = _altura_tela / 3;
    
    //Desenhando menu de opções
    draw_set_color(c_white);
    draw_text_transformed(_centro_x, _inicio_y, "Volume da Música: " + string(round(global.volume_musica * 100)) + "%", 1.5, 1.5, 0);
    
    //Desenhando barra de volume
    var _bar_width = 400;
    var _bar_height = 30;
    var _bar_x = _centro_x - _bar_width/2;
    var _bar_y = _inicio_y + _altura * 2;
    
    // Barra de fundo
    draw_set_color(c_gray);
    draw_rectangle(_bar_x, _bar_y, _bar_x + _bar_width, _bar_y + _bar_height, false);
    
    // Barra de volume
    draw_set_color(c_red);
    draw_rectangle(_bar_x, _bar_y, _bar_x + (_bar_width * global.volume_musica), _bar_y + _bar_height, false);
    
    // Contorno da barra
    draw_set_color(c_white);
    draw_rectangle(_bar_x, _bar_y, _bar_x + _bar_width, _bar_y + _bar_height, true);
    
    //Instruções
    draw_set_color(c_white);
    draw_text_transformed(_centro_x, _bar_y + _bar_height + _altura * 1.5, "← → Ajustar Volume", 1.2, 1.2, 0);
    draw_text_transformed(_centro_x, _bar_y + _bar_height + _altura * 3, "ESC Voltar", 1.2, 1.2, 0);
}

//Resetando configurações de desenho
draw_set_color(-1);
draw_set_font(-1);