// Collision with player
var player = instance_place(x, y, sorin1);
if (player != noone && !player.invencivel) {
    if (estado == "atacando") {
        // Causar dano ao jogador
        with(player) {
            vidas--;
            invencivel = true;
            alarm[0] = tempo_invencibilidade;
            
            // Knockback
            var dir = sign(x - other.x);
            if (dir == 0) dir = 1;
            hspd = dir * 8;
            vspd = -8;
        }
    } else if (player.atacando) {
        // Boss toma dano do jogador
        vida -= 10;
        estado = "parado";
        
        // Knockback no boss
        var dir = sign(x - player.x);
        if (dir == 0) dir = 1;
        hspd = dir * 4;
        
        // Mudar para sprite de dano ou morte
        if (vida <= 0) {
            sprite_index = bossmorrendo;
            estado = "morrendo";
        }
    }
}
