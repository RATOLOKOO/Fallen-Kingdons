// Animação básica
image_speed = 0.5;

// Variável para detectar se já foi coletada
collected = false;
