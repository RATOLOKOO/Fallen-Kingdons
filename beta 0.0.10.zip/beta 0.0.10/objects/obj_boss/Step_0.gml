// Procurar o jogador se ainda não encontrado
if (!alvo) {
    alvo = instance_nearest(x, y, sorin1);
}

// Aplicar gravidade
vspd += grv;

// Lógica baseada no estado
switch(estado) {
    case "parado":
        sprite_index = bossparado;
        hspd = 0;
        
        // Mudar para andando se o jogador estiver próximo
        if (alvo && distance_to_object(alvo) < ataque_range * 1.5) {
            estado = "andando";
            tempo_estado = 0;
        }
        break;
        
    case "andando":
        sprite_index = bossandando;
        
        // Mover em direção ao jogador
        if (alvo) {
            var dir = sign(alvo.x - x);
            hspd = spd * dir;
            image_xscale = -dir; // Virar sprite na direção do movimento
        }
        
        // Mudar para atacando se próximo o suficiente
        if (alvo && distance_to_object(alvo) < ataque_range && ataque_timer <= 0) {
            estado = "atacando";
            tempo_estado = 0;
            ataque_timer = ataque_cooldown;
        }
        break;
        
    case "atacando":
        sprite_index = bossatacando;
        hspd = 0;
        
        // Voltar para andando após a animação
        if (image_index >= image_number - 1) {
            estado = "andando";
            tempo_estado = 0;
        }
        break;
}

// Atualizar timer de ataque
if (ataque_timer > 0) {
    ataque_timer--;
}

// Atualizar timer de estado
tempo_estado++;
if (tempo_estado >= tempo_max_estado) {
    if (estado != "parado") {
        estado = "parado";
        tempo_estado = 0;
    }
}

// Aplicar gravidade se não estiver no chão
if (!place_meeting(x, y + 1, obj_chao)) {
    vspd += grv;
} else {
    vspd = 0;
}

// Aplicar movimento horizontal
x += hspd;

// Colisão horizontal com obj_chao
if (place_meeting(x, y, obj_chao)) {
    if (hspd > 0) {
        x = x - 1;
        while (place_meeting(x, y, obj_chao)) {
            x -= 1;
        }
    } else if (hspd < 0) {
        x = x + 1;
        while (place_meeting(x, y, obj_chao)) {
            x += 1;
        }
    }
    hspd = 0;
}

// Aplicar movimento vertical
y += vspd;

// Colisão vertical com obj_chao
if (place_meeting(x, y, obj_chao)) {
    if (vspd > 0) {
        y = y - 1;
        while (place_meeting(x, y, obj_chao)) {
            y -= 1;
        }
    } else if (vspd < 0) {
        y = y + 1;
        while (place_meeting(x, y, obj_chao)) {
            y += 1;
        }
    }
    vspd = 0;
}
