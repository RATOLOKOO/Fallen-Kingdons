window_set_size(800,500)

// Variáveis de movimento
vspd = 0;       // velocidade vertical
grv = 0.5;      // gravidade
pulo = -10;     // força do pulo (valor negativo porque vai pra cima)
spd = 4;        // velocidade de andar

// Sistema de vida
vidas = 3;      // quantidade de corações
invencivel = false; // estado de invencibilidade
alpha_padrao = 1; // alpha normal do sprite
tempo_invencibilidade = room_speed * 3; // 3 segundos de invencibilidade
tempo_piscar = room_speed / 8; // Velocidade do piscar quando invencível

// Tamanho da câmera
cam_w = 640;
cam_h = 360;

// Cria a câmera
camera = camera_create_view(0, 0, cam_w, cam_h, 0, -1, -1, -1, cam_w/2, cam_h/2);
view_camera[0] = camera;

spawn_x = x;
spawn_y = y;

atacando = false;        // se está atacando agora
tempo_ataque = 25;       // duração do ataque em frames
ataque_timer = 0;        // contador do ataque
ataque_cooldown = 20;    // delay entre ataques (em steps)
cooldown_timer = 0;      // contador do cooldown


