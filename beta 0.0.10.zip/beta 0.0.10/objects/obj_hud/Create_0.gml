//Posição inicial dos corações na tela
coracao_x = 20;
coracao_y = 20;
espaco_entre_coracoes = 40; //Espaço entre cada coração

//Sprite IDs
sprite_coracao_cheio = coracao1;
sprite_coracao_vazio = coracao2;