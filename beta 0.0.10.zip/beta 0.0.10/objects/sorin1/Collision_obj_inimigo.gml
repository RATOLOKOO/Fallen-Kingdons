//Verifica se não está no período de invencibilidade
if (!invencivel)
{
    //Diminui a vida
    vidas--;
    
    //Ativa invencibilidade
    invencivel = true;
    alarm[0] = tempo_invencibilidade; // 3 segundos de invencibilidade
    alarm[1] = tempo_piscar; // Começa o efeito de piscar
    
    //Efeito visual inicial de dano
    image_alpha = 0.5;
    
    //Pequeno knockback ao tomar dano
    var direcao_knockback = point_direction(other.x, other.y, x, y);
    vspd = lengthdir_y(4, direcao_knockback);
    
    //Se acabaram as vidas
    if (vidas <= 0)
    {
        // Apenas desativa o jogador sem reiniciar a sala
        visible = false;
        vidas = 0;
    }
}


