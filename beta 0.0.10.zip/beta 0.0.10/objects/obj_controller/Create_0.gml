// Se estiver na sala do boss
if (room == rm_boss) {
    alarm[0] = 1; // Configurar a sala do boss no próximo frame
} else {
    // Toca a soundtrack de fundo em loop
    audio_play_sound(snd_soundtrack_fase1, 0, true);
}