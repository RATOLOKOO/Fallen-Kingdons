// Garantir que o personagem mantenha suas propriedades ao mudar de sala
if (room == rm_boss) {
    // Garantir que a câmera seja recriada corretamente
    if (variable_instance_exists(id, "camera")) {
        if (camera_get_active() == camera) {
            camera_destroy(camera);
        }
    }
    
    // Recriar a câmera
    camera = camera_create_view(x - (cam_w/2), y - (cam_h/2), cam_w, cam_h);
    view_camera[0] = camera;
    
    // Resetar variáveis de movimento para evitar bugs
    vspd = 0;
    hspd = 0;
    
    // Garantir que o personagem esteja na layer correta
    var inst_layer = layer_get_id("Instances");
    if (inst_layer != -1) {
        layer = inst_layer;
    }
}
