if (global.pause) 
{
	image_speed = 0;
	exit;
}
image_speed = 1;

// === GRAVIDADE ===
if (!place_meeting(x, y + 1, obj_grama)) {
    vspd += grv; // Aplica gravidade
} else {
    vspd = 0;

    // PULO
    if (keyboard_check_pressed(vk_up)) {
        vspd = pulo;
        audio_play_sound(snd_pulando, 0, false); // Toca o som do pulo uma vez
    }
}

// MOVIMENTO VERTICAL
y += vspd;

// CORRIGE SOBREPOSIÇÃO COM O CHÃO
while (place_meeting(x, y, obj_grama)) {
    y -= 1;
}

// === MOVIMENTO HORIZONTAL ===
var andando = false;

if (keyboard_check(vk_left)) {
    x -= spd;
    image_xscale = -1;
    andando = true;
}
if (keyboard_check(vk_right)) {
    x += spd;
    image_xscale = 1;
    andando = true;
}

// === SOM DE CORRER ===
if (andando && place_meeting(x, y + 1, obj_grama) && !atacando) {
    if (!audio_is_playing(snd_correndo)) {
        audio_play_sound(snd_correndo, 0, true); // toca em loop enquanto anda
    }
} else {
    audio_stop_sound(snd_correndo); // para o som se não estiver andando
}

// === ATAQUE ===
// Início do ataque ao clicar
if (mouse_check_button_pressed(mb_left) && !atacando) {
    atacando = true;
    ataque_timer = tempo_ataque;
    sprite_index = sorinatacando;    // muda para o sprite de ataque
    image_index = 0;                 // reinicia a animação
    image_speed = 2;                 // velocidade da animação
    // audio_play_sound(snd_ataque, 0, false); // se tiver som do ataque
}

// Só dá dano quando estiver atacando
if (atacando) {
    // Detecta inimigos próximos (colisão)
    with (instance_place(x, y, obj_inimigo)) {
        vida -= 1; // diminui a vida do inimigo
    }
}

// Se estiver atacando, conta o tempo
if (atacando) {
    ataque_timer -= 1;

    // Quando terminar o tempo, volta para sprite normal
    if (ataque_timer <= 0) {
        atacando = false;
    }
}

// === COLISÃO COM INIMIGO ===
// Verifica se há inimigo no mesmo lugar do player
var inimigo = instance_place(x, y, obj_inimigo);

if (inimigo != noone) {
    if (atacando) {
        // Se estiver atacando → causa dano ao inimigo e o destrói se a vida chegar a 0
        with (inimigo) {
            vida -= 1; // reduz vida do inimigo
            if (vida <= 0) {
                instance_destroy(); // destrói o inimigo se a vida chegar a 0
            }
        }
    } else if (!invencivel) {
        // Se não estiver atacando e não estiver invencível
        // Reduz a vida do Sorin
        vidas--;
        
        // Ativa invencibilidade
        invencivel = true;
        alarm[0] = tempo_invencibilidade; // 3 segundos de invencibilidade
        alarm[1] = tempo_piscar; // Começa o efeito de piscar
        
        // Calcula a direção do knockback baseado nas posições
        var dir = point_direction(inimigo.x, inimigo.y, x, y);
        
        // Aplica o knockback
        x += lengthdir_x(32, dir);
        y += lengthdir_y(16, dir);
        
        // Garante que não fique preso em paredes
        while (place_meeting(x, y, obj_grama)) {
            y -= 1;
        }
        
        // Aplica um pequeno impulso vertical
        vspd = -4;
    }
}

// === ANIMAÇÕES (só se NÃO estiver atacando) ===
if (!atacando) {
    if (vspd != 0) {
        sprite_index = sorinAndando; // ou sorinPulando se tiver
    } else if (andando) {
        sprite_index = sorinAndando;
    } else {
        sprite_index = sorin;
    }
}

// === CÂMERA CENTRALIZADA ===
var cam_w = camera_get_view_width(view_camera[0]);
var cam_h = camera_get_view_height(view_camera[0]);

// Calcula o alvo do centro
var alvo_x = x - cam_w / 2;
var alvo_y = y - cam_h / 2;

// Limita para não passar da borda da room
alvo_x = clamp(alvo_x, 0, room_width - cam_w);
alvo_y = clamp(alvo_y, 0, room_height - cam_h);

// Opcional: suavização
var cam_x = camera_get_view_x(view_camera[0]);
var cam_y = camera_get_view_y(view_camera[0]);

cam_x = lerp(cam_x, alvo_x, 0.1); // 0.1 = suavização; menor = mais suave
cam_y = lerp(cam_y, alvo_y, 0.1);

// Atualiza a posição da câmera
camera_set_view_pos(view_camera[0], cam_x, cam_y);

// Se cair fora da fase (por ex. y > room_height)
if (y > room_height) {
    // volta pro spawn
    x = spawn_x;
    y = spawn_y;
    vspd = 0; // zera velocidade vertical
}
