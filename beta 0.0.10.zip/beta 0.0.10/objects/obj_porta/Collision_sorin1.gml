if (!usada) {
    usada = true;
    
    // Tornar o personagem persistente
    with(other) {
        persistent = true;
    }
    
    // Salvar a posição de destino em variáveis globais
    global.player_start_x = destino_x;
    global.player_start_y = destino_y;
    
    // Parar todos os sons
    audio_stop_all();
    
    // Ir para a sala do boss
    room_goto(rm_boss);
    
    // Criar um alarme para posicionar o jogador
    alarm[0] = 1;
}