//se apertar esc o jogo pausa
if keyboard_check_released(vk_escape) {
    global.pause = !global.pause;
    
    if(global.pause) {
        // Pausar o jogo
        with(all) {
            if(object_index != obj_pause && object_index != obj_hud) {
                image_speed = 0;  // Pausa as animações
                speed = 0;        // Pausa o movimento
            }
        }
        audio_pause_sound(snd_soundtrack_fase1);  // Pausa apenas a música de fundo
    } else {
        // Despausar o jogo
        with(all) {
            if(object_index != obj_pause && object_index != obj_hud) {
                image_speed = 1;  // Retoma as animações
                // Não restauramos speed aqui para evitar bugs de movimento
            }
        }
        audio_resume_sound(snd_soundtrack_fase1);  // Resume apenas a música de fundo
    }
}