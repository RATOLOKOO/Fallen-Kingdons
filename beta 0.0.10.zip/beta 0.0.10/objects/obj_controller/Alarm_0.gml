// Se estamos na sala do boss
if (room == rm_boss) {
    // Criar o jogador
    var _player = instance_create_layer(64, room_height - 128, "Instances", sorin1);
    
    // Criar o boss
    var _boss = instance_create_layer(room_width - 192, room_height - 192, "Instances", obj_boss);
    
    // Garantir que não há sons indesejados tocando
    audio_stop_sound(snd_correndo);
    
    // Garantir que o pause está desativado e o jogo está rodando
    global.pause = false;
    game_set_speed(60, gamespeed_fps);
    
    // Inicializar variáveis do jogador explicitamente
    with(_player) {
        vspd = 0;
        grv = 0.5;
        pulo = -10;
        spd = 4;
        image_speed = 1;
    }
    
    // Inicializar variáveis do boss explicitamente
    with(_boss) {
        vspd = 0;
        grv = 0.5;
        spd = 2;
        image_speed = 1;
    }
}