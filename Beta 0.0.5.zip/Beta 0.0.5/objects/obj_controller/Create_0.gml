// Toca a soundtrack de fundo em loop
audio_play_sound(snd_soundtrack_fase1, 0, true);