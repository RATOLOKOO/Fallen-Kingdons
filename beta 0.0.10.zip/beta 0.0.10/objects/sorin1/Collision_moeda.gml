/// @description Coleta moeda

// Destruir a moeda coletada
with(other) {
    instance_destroy();
}

// Aqui você pode adicionar:
// - Som de coleta de moeda
// - Aumentar a pontuação
// - Efeito visual
// - etc.