// Definir a posição onde o jogador deve aparecer na próxima sala
destino_x = 64; // Posição X onde o jogador aparecerá na sala do boss
destino_y = 352; // Posição Y onde o jogador aparecerá na sala do boss (um pouco acima do chão)

// Flag para controlar se a porta já foi usada
usada = false;
