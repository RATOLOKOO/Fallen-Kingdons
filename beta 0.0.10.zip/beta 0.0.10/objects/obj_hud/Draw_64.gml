//Encontrar o jogador se ainda não encontramos
var _player = instance_nearest(0, 0, sorin1);

//Desenhando os corações
if (instance_exists(_player))
{
    //Se o jogador não tem a variável vidas, define como 3
    if (!variable_instance_exists(_player, "vidas"))
    {
        _player.vidas = 3;
    }
    
    //Definindo as posições e tamanho dos corações
    var coracao_x = 64;  // Aumentei a posição inicial para dar mais espaço
    var coracao_y = 64;  // Aumentei a posição inicial para dar mais espaço
    var espaco_entre_coracoes = 100; // Aumentei o espaço entre os corações
    var escala = 2.5; // Isso fará os corações ficarem 2.5 vezes maiores
    
    //Desenha os 3 corações
    for(var i = 0; i < 3; i++)
    {
        var _sprite = Sprite15; //Coração vazio por padrão
        
        //Se o jogador tem vida suficiente, desenha coração cheio
        if (i < _player.vidas)
        {
            _sprite = object_get_sprite(coracao1); //Coração cheio
        }
        
        //Desenha o coração na posição correta com o tamanho aumentado
        draw_sprite_ext(_sprite, 0, 
            coracao_x + (espaco_entre_coracoes * i), 
            coracao_y, 
            escala, escala, // Escala X e Y
            0, // Rotação
            c_white, // Cor
            1 // Alpha (transparência)
        );
    }
}