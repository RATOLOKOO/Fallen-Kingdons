//Fim do período de invencibilidade
invencivel = false;
image_alpha = alpha_padrao; //Volta ao normal