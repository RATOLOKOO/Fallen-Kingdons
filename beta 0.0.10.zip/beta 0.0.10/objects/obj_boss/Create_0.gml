// Inicializar variáveis do boss
vspd = 0;
hspd = 0;
grv = 0.5;
spd = 2;
vida = 100;

// Variáveis de ataque
ataque_range = 150;    // Distância para começar a atacar
ataque_cooldown = room_speed * 2;  // 2 segundos entre ataques
ataque_timer = 0;

// Estado inicial
estado = "parado";
sprite_index = bossparado;
image_speed = 1;

// Target (player)
alvo = noone;

// Tempo entre mudanças de estado
tempo_estado = 0;
tempo_max_estado = room_speed * 3;  // 3 segundos em cada estado

// Configuração de colisão
var layer_id = layer_get_id("Instances_1");
var tilemap_id = layer_tilemap_get_id(layer_id);
if (tilemap_id == -1) {
    // Se não encontrar no Instances_1, procura em outras layers
    layer_id = layer_get_id("Collision");
    tilemap_id = layer_tilemap_get_id(layer_id);
}
tilemap = tilemap_id;
