//Variável global para controlar a opção selecionada
if(!variable_global_exists("menu_selected")) {
    global.menu_selected = 0;
}

//Exibindo se o jogo está ou não pausado
if(global.pause)
{
    //Controle de navegação com teclado
    if(keyboard_check_pressed(vk_up)) {
        global.menu_selected = 0;
    }
    if(keyboard_check_pressed(vk_down)) {
        global.menu_selected = 1;
    }
    
    //Escurecendo a tela
    var gui_width = display_get_gui_width();
    var gui_height = display_get_gui_height();
    
    draw_set_alpha(0.7);
    draw_rectangle_color(0, 0, gui_width, gui_height, c_black, c_black, c_black, c_black, false);
    draw_set_alpha(1);

    //Configurando a fonte e alinhamento
    draw_set_font(fnt_pause);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    
    //Título do menu
    draw_set_color(c_white);
    draw_text_transformed(gui_width/2, gui_height/3, "JOGO PAUSADO", 1.5, 1.5, 0);
    
    //Configurações dos botões
    var btn_width = 200;
    var btn_height = 50;
    var menu_y = gui_height/2;
    var spacing = 70;
    
    //Botão Continuar
    var continuar_y = menu_y;
    draw_set_color(c_black);
    draw_rectangle(gui_width/2 - btn_width/2, continuar_y - btn_height/2,
                  gui_width/2 + btn_width/2, continuar_y + btn_height/2, false);
    
    //Desenha o botão Continuar com cor baseada na seleção
    if(global.menu_selected == 0)
    {
        draw_set_color(c_yellow);
        //Se pressionar Enter na opção selecionada
        if(keyboard_check_pressed(vk_enter))
        {
            with(all) {
                if(object_index != obj_pause && object_index != obj_hud) {
                    image_speed = 1;  // Retoma as animações
                }
            }
            global.pause = false;
        }
    }
    else
    {
        draw_set_color(c_white);
    }
    draw_text(gui_width/2, continuar_y, "CONTINUAR");
    
    //Botão Sair
    var sair_y = menu_y + spacing;
    draw_set_color(c_black);
    draw_rectangle(gui_width/2 - btn_width/2, sair_y - btn_height/2,
                  gui_width/2 + btn_width/2, sair_y + btn_height/2, false);
    
    //Desenha o botão Sair com cor baseada na seleção
    if(global.menu_selected == 1)
    {
        draw_set_color(c_yellow);
        //Se pressionar Enter na opção selecionada
        if(keyboard_check_pressed(vk_enter))
        {
            audio_stop_sound(snd_soundtrack_fase1);  // Para a música antes de mudar de sala
            with(all) {
                image_speed = 1;  // Restaura as animações
            }
            global.pause = false;
            game_restart();  // Reinicia o jogo completamente para evitar problemas de proporção
        }
    }
    else
    {
        draw_set_color(c_white);
    }
    draw_text(gui_width/2, sair_y, "SAIR");







}
