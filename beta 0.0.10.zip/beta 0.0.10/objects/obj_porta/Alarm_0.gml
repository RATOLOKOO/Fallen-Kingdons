// Posicionar o jogador existente no ponto de destino
if (instance_exists(sorin1)) {
    with(sorin1) {
        x = global.player_start_x;
        y = global.player_start_y;
    }
}

// Destruir a porta após a transição
instance_destroy();
    view_camera[0] = camera;
 

// Criar o boss
instance_create_layer(room_width - 192, room_height - 192, "Instances", obj_boss);

// Inicializar o controller da sala se necessário
if (!instance_exists(obj_controller)) {
    instance_create_layer(0, 0, "Instances", obj_controller);
}

// Destruir a porta após configurar tudo
instance_destroy();