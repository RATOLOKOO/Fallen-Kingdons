// Variáveis do inimigo
vida = 1; // quantidade de vida do inimigo
velocidade = 2;
direcao = 1;
image_xscale = direcao;