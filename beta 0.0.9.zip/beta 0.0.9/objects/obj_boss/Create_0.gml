// Inicializar variáveis do boss
vspd = 0;
grv = 0.5;
spd = 2;

// Estado inicial
estado = "parado";
sprite_index = bossparado;
