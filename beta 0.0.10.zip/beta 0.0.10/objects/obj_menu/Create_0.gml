//Criando as estruturas do menu
opcao1 =
{
	texto : "Jogar",
	funcao : function()
	{
		// Para a música do menu
		if (audio_is_playing(snd_soundtrack_fase1))
		{
			audio_stop_sound(snd_soundtrack_fase1);
		}
		
		// Muda para a sala do jogo
		room_goto(rm_jogo);
		
		// Reinicia a música do jogo com o volume atual
		audio_play_sound(snd_soundtrack_fase1, 1, true);
		audio_sound_gain(snd_soundtrack_fase1, global.volume_musica, 0);
	},
}

opcao2 =
{
	texto : "Opções",
	funcao : function()
	{
		global.menu_estado = "opcoes";
	},
}

opcao3 =
{
	texto : "Sair",
	funcao : function()
	{
		game_end();
	},
}

//Menu
menu = [opcao1, opcao2, opcao3];

//Configurações iniciais
global.menu_estado = "principal";
global.volume_musica = 1; // Volume da música (0 a 1)

//Tocando a música do menu
if (!audio_is_playing(snd_soundtrack_fase1))
{
    audio_play_sound(snd_soundtrack_fase1, 1, true);
    audio_sound_gain(snd_soundtrack_fase1, global.volume_musica, 0);
}

//Variavel para saber qual o indice atual
atual = 0;


//Margem do menu
margem = 0;